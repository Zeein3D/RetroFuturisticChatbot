const messages = document.getElementById('messages');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');

sendButton.addEventListener('click', () => {
    const userMessage = userInput.value;
    if (userMessage.trim() === '') return;

    // Display user message
    const userMessageElement = document.createElement('div');
    userMessageElement.textContent = `You: ${userMessage}`;
    messages.appendChild(userMessageElement);

    // Clear input
    userInput.value = '';

    // Simulate AI response
    const aiMessageElement = document.createElement('div');
    aiMessageElement.textContent = 'AI: Thinking...';
    messages.appendChild(aiMessageElement);

    // Simulate delay for AI response
    setTimeout(() => {
        aiMessageElement.textContent = 'AI: Hello! How can I assist you today?';
    }, 1000);
});